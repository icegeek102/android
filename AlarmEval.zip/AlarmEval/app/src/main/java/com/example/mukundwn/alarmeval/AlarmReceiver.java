package com.example.mukundwn.alarmeval;

import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.view.View;

public class AlarmReceiver extends WakefulBroadcastReceiver {
    public static Ringtone ringtone;
    public void onReceive(final Context context, Intent intent) {
        MainActivity.getTextView2().setText("YOU'VE TO GET UP TO WORK NOW!");
        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        ringtone = RingtoneManager.getRingtone(context, uri);
        ringtone.play();
        MainActivity.snooze.setVisibility(View.VISIBLE);
    }
}